

/*--$(function(){
    $("#pageRefresh").click(function(){
        $(this).style.font="italic bold 12px arial,serif";
        });
    });--*/
	
	$(function(){
		var size=1;
		var url="https://ny-gateway.chngdz.com/waybill/waybill/outsourcing_list?size="+size+"&page=1&logisticsNo=";

		$("#submit").click(function(){
			newurl=url+$("#orderid").val()
			$.getJSON(newurl, function (res){
				if(res){
					$.each(res,function(i,field){
						if(i=="total"){
						size=field;
						newurl="https://ny-gateway.chngdz.com/waybill/waybill/outsourcing_list?size="+size+"&page=1&logisticsNo="+$("#orderid").val();
						$.getJSON(newurl, function (res){
							if(res){
								$.each(res,function(i,field){
									$("#result").append("<div>"+i+" "+field[0]+"</div>");
								}
								)}
						})

					   // return vnumber
						};
					});
			}
		}

		
/*
	$('body').on('mousedown','img',function(e){ 
		if( e.button == 2 ) { 
			alert($(this).attr('src')); 
			return false; 
		} 
		return true; 
		});*/

	
	)})});
